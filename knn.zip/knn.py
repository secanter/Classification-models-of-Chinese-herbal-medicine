import os
import cv2
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report
# https://blog.csdn.net/Eastmount/article/details/115382688?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522166710779116800180615227%2522%252C%2522scm%2522%253A%252220140713.130102334.pc%255Fblog.%2522%257D&request_id=166710779116800180615227&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~blog~first_rank_ecpm_v1~rank_v31_ecpm-1-115382688-null-null.nonecase&utm_term=knn&spm=1018.2226.3001.4450
# https://blog.csdn.net/qq_52309640/article/details/120941410

X = [] #定义图像名称
Y = [] #定义图像分类类标
Z = [] #定义图像像素


os.chdir("data")
cnames=os.listdir()
for _ in cnames:
    # 获取图像名称
    os.chdir(_)
    names = os.listdir()
    for name in names:
        X.append("data//" + _ + "//" + name)
        Y.append(_)
    os.chdir("../")
    # 获取图像类标即为文件夹名称
os.chdir("../")

X = np.array(X)
Y = np.array(Y)
# print(X,Y)
#随机率为100% 选取其中的30%作为测试集
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.1, random_state=1)

# print(len(X_train), len(X_test), len(y_train), len(y_test))

#----------------------------------------------------------------------------------
# 第二步 图像读取及转换为像素直方图
#----------------------------------------------------------------------------------

# 训练集
XX_train = []
for i in X_train:
    # 读取图像
    # print i
    image = cv2.imread(i)

    # 图像像素大小一致
    img = cv2.resize(image, (256, 256),
                     interpolation=cv2.INTER_CUBIC)

    # 计算图像直方图并存储至X数组
    hist = cv2.calcHist([img], [0, 1], None,
                        [256, 256], [0.0, 255.0, 0.0, 255.0])

    XX_train.append(((hist / 255).flatten()))


# 测试集
XX_test = []
for i in X_test:
    # 读取图像
    # print i
    image = cv2.imread(i)

    # 图像像素大小一致
    img = cv2.resize(image, (256, 256),
                     interpolation=cv2.INTER_CUBIC)

    # 计算图像直方图并存储至X数组
    hist = cv2.calcHist([img], [0, 1], None,
                        [256, 256], [0.0, 255.0, 0.0, 255.0])

    XX_test.append(((hist / 255).flatten()))


#----------------------------------------------------------------------------------
# 第三步 基于KNN的图像分类处理
#----------------------------------------------------------------------------------



from sklearn.neighbors import KNeighborsClassifier
clf = KNeighborsClassifier(n_neighbors=18).fit(XX_train, y_train)
predictions_labels = clf.predict(XX_test)

print('预测结果:')
print(predictions_labels)

print('算法评价:')
print((classification_report(y_test, predictions_labels)))
# 绘制混淆矩阵
import itertools
import matplotlib.pyplot as plt
import numpy as np
def plot_confusion_matrix(cm, classes, normalize=False, title='Confusion matrix', cmap=plt.cm.Blues):
    """
    - cm : 计算出的混淆矩阵的值
    - classes : 混淆矩阵中每一行每一列对应的列
    - normalize : True:显示百分比, False:显示个数
    """
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("显示百分比：")
        np.set_printoptions(formatter={'float': '{: 0.2f}'.format})
        print(cm)
    else:
        print('显示具体数字：')
        print(cm)
    fig = plt.figure(figsize=(19, 18))
    fig.patch.set_facecolor('white')
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    fig = plt.figure(figsize=(19, 18))
    fig.patch.set_facecolor('white')
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)
    # matplotlib版本问题，如果不加下面这行代码，则绘制的混淆矩阵上下只能显示一半，有的版本的matplotlib不需要下面的代码，分别试一下即可
    plt.ylim(len(classes) - 0.5, -0.5)
    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")
    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.savefig("./KNN_confusion_matrix.png")
    plt.show()

cnf_matrix=confusion_matrix(y_test,predictions_labels)
print(cnf_matrix)
attack_types=cnames.copy()
# plot_confusion_matrix(cnf_matrix, classes=attack_types, normalize=False, title='Normalized confusion matrix')
plot_confusion_matrix(cnf_matrix, classes=attack_types, normalize=True, title='Normalized confusion matrix')


